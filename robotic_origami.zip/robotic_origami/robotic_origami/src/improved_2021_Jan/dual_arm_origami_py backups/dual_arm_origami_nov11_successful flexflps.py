#!/usr/bin/env python
import tf_conversions
import numpy as np
import message_filters
import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import time
import roslib; roslib.load_manifest('ur_driver')
roslib.load_manifest('ur_moveit_myplan')
import rospy
import actionlib
import tf
from std_msgs.msg import Int8
from ur_moveit_myplan.msg import qr_status
from apriltag_ros.msg import AprilTagDetection, AprilTagDetectionArray
from control_msgs.msg import *
from trajectory_msgs.msg import *
from sensor_msgs.msg import JointState
from math import sqrt, pi, acos, sin, cos
from moveit_msgs.msg import RobotTrajectory
from moveit_msgs.msg import *
from trajectory_msgs.msg import JointTrajectoryPoint
from geometry_msgs.msg import PoseStamped, Pose
from math import sqrt, pi, acos, sin, cos , atan2, tan
from std_msgs.msg import String,Empty,UInt16


moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node('dual_arm_origami', anonymous=True)
listener = tf.TransformListener()
robot = moveit_commander.RobotCommander()
scene = moveit_commander.PlanningSceneInterface()
rospy.sleep(2)
group_name1 = "hong_arm"
group1 = moveit_commander.MoveGroupCommander(group_name1)
group_name2 = "kong_arm"
group2 = moveit_commander.MoveGroupCommander(group_name2)
group_name3 = "hong_hand"
group3 = moveit_commander.MoveGroupCommander(group_name3)
group_name4 = "kong_hand"
group4 = moveit_commander.MoveGroupCommander(group_name4)
###set rigid gripper pose group.set_joint_value_target([1]) ---> group.go()
display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',
                                               moveit_msgs.msg.DisplayTrajectory,
                                               queue_size=20)

from arc_rotate import *
global odom_c_pub
# diaplay center point
odom_c_pub = rospy.Publisher("/odom_c", Odometry, queue_size=50)

#global motion group
global display_trajectory_trigger_pub
display_trajectory_trigger_pub = rospy.Publisher(
                                      '/display_trigger',
                                      String,
                                      queue_size=20)

print "============  Start now"

def gripper_pose(angle,gripper_name):
##input angle in degree
  if gripper_name == "hong_hand":
    group = group3
  elif gripper_name == "kong_hand":
    group = group4
  else:
    print "robot_arm input error, please input valid robot_arm name"
  angle=angle*pi/180
  group.set_joint_value_target([angle]) 
  result=group.go()    
  print "============ Gripper: %s target: %s " % (gripper_name, angle)
  print "============ result:%s" % result

def addCollisionObjects():
    global wall_pose1
    global wall_name1
    wall_pose1 = geometry_msgs.msg.PoseStamped()
    wall_pose1.header.frame_id = "world"
    wall_pose1.pose.orientation.w = 1.0
    wall_pose1.pose.orientation.x = 0
    wall_pose1.pose.orientation.y = 0
    wall_pose1.pose.orientation.z = 1
    wall_pose1.pose.position.x = -2.1
    wall_pose1.pose.position.y = 0.0
    wall_pose1.pose.position.z = 1.0
    wall_name1 = "wall1"
    global wall_pose2
    global wall_name2
    wall_pose2 = geometry_msgs.msg.PoseStamped()
    wall_pose2.header.frame_id = "world"
    wall_pose2.pose.orientation.w = 1.0
    wall_pose2.pose.orientation.x = 0
    wall_pose2.pose.orientation.y = 0
    wall_pose2.pose.orientation.z = 1
    wall_pose2.pose.position.x = 2.1
    wall_pose2.pose.position.y = 0.0
    wall_pose2.pose.position.z = 1.0
    wall_name2 = "wall2"  


#    hongjoint_values = [-51.56/180*pi, -80.46/180*pi, -114.9/180*pi, -50.93/180*pi, 70.64/180*pi, -54.45/180*pi]
def robhong_go_to_home(state):
    if state == 1:        
        joint_values = [-66.86/180*pi, -69.6/180*pi, -120.2/180*pi, -51.78/180*pi, 77.87/180*pi, 111.00/180*pi]
    elif state == 2:
        joint_values = []
    group1.set_joint_value_target(joint_values)
    plan = group1.plan()
    print "============ hong_home"
    rospy.sleep(2)
    scaled_traj2 = scale_trajectory_speed(plan, 0.5)
    group1.execute(scaled_traj2)

def robkong_go_to_home(state):
    if state == 1:
        joint_values = [45.80/180*pi, -108.10/180*pi, 111.35/180*pi, -113.3/180*pi, -72.05/180*pi, 47.2/180*pi]
    elif state == 2:
        joint_values = []
    group2.set_joint_value_target(joint_values)
    plan = group2.plan()
    print "============ kong_home"
    rospy.sleep(2)
    scaled_traj2 = scale_trajectory_speed(plan, 0.5)
    group2.execute(scaled_traj2)

def move_target(x, y, z, ox, oy, oz, ow, vel,robot_arm):

  if robot_arm == "robhong":
      group = group1
  elif robot_arm == "robkong":
      group = group2
  else:
      print "robot_arm input error, please input valid robot_arm name"
  return 0      
  pose_target = geometry_msgs.msg.Pose()
  pose_target.orientation.x = ox
  pose_target.orientation.y = oy
  pose_target.orientation.z = oz
  pose_target.orientation.w = ow
  pose_target.position.x = x
  pose_target.position.y = y
  pose_target.position.z = z
  group.set_pose_target(pose_target)
  plan = group.plan()
  scaled_traj = scale_trajectory_speed(plan, vel)
  print "move_target"
  group.execute(scaled_traj)

def move_waypoints(dx,dy,dz,vel,robot_arm):
    '''
    This function is used for moving position of tool0 link of robot_arm.
    Input: difference between target position and initial position
    Output: execute a straight line trajectory between target and initial position
    '''
    if robot_arm == "robhong":
        group = group1
    elif robot_arm == "robkong":
        group = group2
    else:
        print "robot_arm input error, please input valid robot_arm name"
        return 0        
    waypoints = []
    waypoints.append(group.get_current_pose().pose)
    wpose = copy.deepcopy(group.get_current_pose().pose)
    wpose.position.x += dx
    wpose.position.y += dy
    wpose.position.z += dz
    waypoints.append(copy.deepcopy(wpose))
    (plan, fraction) = group.compute_cartesian_path(waypoints, 0.01, 0.0)
    new_traj = scale_trajectory_speed(plan,vel)
    result=group.execute(new_traj)
    print "move waypoint result"
    print dx,dy,dz,robot_arm
    print result



def scale_trajectory_speed(traj, scale):
    new_traj = moveit_msgs.msg.RobotTrajectory()
    new_traj.joint_trajectory = traj.joint_trajectory
    n_joints = len(traj.joint_trajectory.joint_names)
    n_points = len(traj.joint_trajectory.points)
    points = list(traj.joint_trajectory.points)

    for i in range(n_points):
        point = trajectory_msgs.msg.JointTrajectoryPoint()
        point.time_from_start = traj.joint_trajectory.points[i].time_from_start / scale
        point.velocities = list(traj.joint_trajectory.points[i].velocities)
        point.accelerations = list(traj.joint_trajectory.points[i].accelerations)
        point.positions = traj.joint_trajectory.points[i].positions

        for j in range(n_joints):
            point.velocities[j] = point.velocities[j] * scale
            point.accelerations[j] = point.accelerations[j] * scale * scale
        points[i] = point

    new_traj.joint_trajectory.points = points
    return new_traj
  



def fold(global_axis,degree,robot_arm):
  trans_soft=[]
  if robot_arm == "robhong":
      group = group1
      listener.waitForTransform("world", "pinch_tip_hong", rospy.Time(), rospy.Duration(4.0))
      (trans_soft,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  elif robot_arm == "robkong":
      group = group2
      listener.waitForTransform("world", "pinch_tip_kong", rospy.Time(), rospy.Duration(4.0))
      (trans_soft,rot_) = listener.lookupTransform("world", "pinch_tip_kong", rospy.Time(0))
  else:
      print "robot_arm input error, please input valid robot_arm name"
      return 0       

  group_rotate_by_external_axis(trans_soft,global_axis,degree,robot_arm)
  rospy.sleep(1)

def group_rotate_by_external_axis(center_point, axis, total_angle,robot_arm):
  global odom_c_pub
  if robot_arm == "robhong":
      group = group1
  elif robot_arm == "robkong":
      group = group2
  else:
      print "robot_arm input error, please input valid robot_arm name"
      return 0   
  pose_target = group.get_current_pose().pose
  
  waypoints_new = calc_waypoints_ARC(pose_target, center_point, axis, total_angle, odom_c_pub)
  # Before the execution of the real robot, turn on the display of the end effector's position and orientation
  # display end effector's trajectory
  # subcriber of display_trajectory_trigger and corresponding function is implemented in 'display_markers.py'
  display_trajectory_trigger_pub.publish('on')
  rospy.sleep(1)

  # Utilize 'compute_cartesian_path' to get a smooth trajectory
  (plan3, fraction) = group.compute_cartesian_path(
                               waypoints_new,   # waypoints to follow
                               0.01,        # eef_step
                               0.0)         # jump_threshold

  # Move the robot with the ARC trajectory
  caled_plan = scale_trajectory_speed(plan3, 0.3)
  group.execute(caled_plan)
  rospy.sleep(1)

  # Stop displaying end effector's posision and orientation
  display_trajectory_trigger_pub.publish('close')

def descend_to_desktop(robot_arm,margin):
    if robot_arm == "robhong":
      group = group1
    elif robot_arm == "robkong":
      group = group2
    else:
      print "robot_arm input error, please input valid robot_arm name"

    pose_target = copy.deepcopy(group.get_current_pose().pose)
    pose_target.position.z = 0.832+margin
    group.set_pose_target(pose_target)
    plan = group.plan()
    scaled_traj = scale_trajectory_speed(plan, 0.3)
    result=group.execute(scaled_traj)
    print "=========== %s descend_to_desktop: %s" % (robot_arm,result)

def move_along_axis(axis,dist,robot_arm):
    if robot_arm == "robhong":
      group = group1
    elif robot_arm == "robkong":
      group = group2
    else:
      print "robot_arm input error, please input valid robot_arm name"
    targ_x=axis[0]*dist
    targ_y=axis[1]*dist
    targ_z=axis[2]*dist
    move_waypoints(targ_x,targ_y,targ_z,0.3,robot_arm)

def flexflip_1():


  #z_margin is a small number for fine tuning of flexflip z-axis
  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)

  ##############kong_arm to initial pose
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  (trans_tag17,rot_) = listener.lookupTransform("world", "tag_17", rospy.Time(0))
  (trans_tag27,rot_) = listener.lookupTransform("world", "tag_27", rospy.Time(0))
  (trans_tag21,rot_) = listener.lookupTransform("world", "tag_21", rospy.Time(0))
  trans_soft2tag = np.subtract(trans_tag17,trans_soft).tolist()
  move_waypoints(trans_soft2tag[0]-0.01,trans_soft2tag[1]-0.01,0.00,0.3,'robkong')

  phi=30
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  group_rotate_by_external_axis(trans_soft, [0, 1.0, 0], phi,"robkong")
  phi=-135
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  group_rotate_by_external_axis(trans_soft, [0, 0, 1.0], phi,"robkong")
  po_cr = group2.get_current_pose().pose

  #kong_arm descend
  descend_to_desktop('robkong',0.006)
 # move_target(po_cr.position.x, po_cr.position.y, po_cr.position.z, 0, -1, 0, 0,0.2,'robkong')


  ##############hong_arm to fix the object
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  trans_rig2tag = np.subtract(trans_tag27,trans_rigH).tolist()
  print "hong trans_rig2tag"
  print trans_rig2tag

  phi=-30
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  group_rotate_by_external_axis(trans_rigH, [0, 1, 0], phi,"robhong")
  phi=-135
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  group_rotate_by_external_axis(trans_rigH, [0, 0, 1], phi,"robhong")

  move_waypoints(trans_rig2tag[0],trans_rig2tag[1],0.0,0.3,'robhong')
  #hong_arm descend
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  trans_rig2tag= np.subtract(trans_tag27,trans_rigH).tolist()
  descend_to_desktop('robhong',0.006)
 

  ####################################### flex-flip and grasp
  arduino_pub.publish(202)
  rospy.sleep(1)

  move_waypoints(0,0,0.01,0.05,'robkong')
  rospy.sleep(2)
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  phi =15
  external_axis_center=trans_soft
  group_rotate_by_external_axis(external_axis_center, [0.7071, -0.7071, 0], phi,'robkong')
  move_waypoints(0.0,0.0,0.01,0.3,'robkong')
  rospy.sleep(1)
  arduino_pub.publish(203)
  rospy.sleep(2)
  
  crease_axis=[0.7071, -0.7071, 0]
  perp_axis=[-0.7071,-0.7071,0]
  crease_perp_l=0.03
  degree=20
  fold(crease_axis,degree,'robkong')

  listener.waitForTransform("world", "pinch_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_pinch,rot_) = listener.lookupTransform("world", "pinch_tip_kong", rospy.Time(0))
  delta_z=-trans_pinch[2]+0.708+0.05
  move_waypoints(0,0,delta_z,0.03,'robkong')
  fold_angle=-45
  fold(crease_axis,fold_angle,'robkong')
  move_along_axis(perp_axis,-crease_perp_l,'robkong')

  listener.waitForTransform("world", "pinch_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_pinch,rot_) = listener.lookupTransform("world", "pinch_tip_kong", rospy.Time(0))
  delta_z=-trans_pinch[2]+0.708
  move_waypoints(0,0,delta_z,0.03,'robkong')

  robhong_go_to_home(1)
  fold_angle=-25
  fold(crease_axis,fold_angle,'robkong')


def flexflip_2():
  
  ##IN CONVENTION: crease_axis and perp_axis have negative y axis value 

  target_tag="tag_15"
  target_rot_angle=-45.0

  fixed_tag="tag_27"
  fix_rot_angle=-135.0

  crease_axis=[-0.7071, -0.7071, 0]
  perp_axis=[0.7071,-0.7071,0]
  crease_perp_l=0.07

  rot1_angle =-15
  rot2_angle=-20
  rot3_angle=45
  rot4_angle=25
  ########## flexflip starts here
  ############## init grippers
  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)

  #####Obtain key info of tags
  (trans_tag17,rot_) = listener.lookupTransform("world", target_tag, rospy.Time(0))
  (trans_tag27,rot_) = listener.lookupTransform("world", fixed_tag, rospy.Time(0))

  ##############kong_arm to initial pose
  phi=30
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  group_rotate_by_external_axis(trans_soft, [0, 1.0, 0], phi,"robkong")
  phi=  target_rot_angle
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  group_rotate_by_external_axis(trans_soft, [0, 0, 1.0], phi,"robkong")

  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  #move to top of target tag
  trans_soft2tag = np.subtract(trans_tag17,trans_soft).tolist()
  margin_x=perp_axis[0]*0.02
  margin_y=perp_axis[1]*0.01
  move_waypoints(trans_soft2tag[0]+margin_x,trans_soft2tag[1]+margin_y,0.00,0.3,'robkong')

  #kong_arm descend
  descend_to_desktop('robkong',0.006)

  ##############hong_arm to fix the object
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  trans_rig2tag = np.subtract(trans_tag27,trans_rigH,).tolist()
  print "hong trans_rig2tag"
  print trans_rig2tag

  phi=-30
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  group_rotate_by_external_axis(trans_rigH, [0, 1, 0], phi,"robhong")
  phi=fix_rot_angle
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  group_rotate_by_external_axis(trans_rigH, [0, 0, 1], phi,"robhong")

  #move to fixed tag
  move_waypoints(trans_rig2tag[0],trans_rig2tag[1],0.0,0.3,'robhong')
  #hong_arm descend
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  trans_rig2tag= np.subtract(trans_tag27,trans_rigH).tolist()
  descend_to_desktop('robhong',0.006)

  ####################################### flex-flip and grasp
  arduino_pub.publish(202)
  rospy.sleep(1)

  move_waypoints(0,0,0.01,0.05,'robkong')
  rospy.sleep(2)
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  #rot1: to hold the paper after flexflip
  group_rotate_by_external_axis(trans_soft, crease_axis, rot1_angle,'robkong')
  move_waypoints(0.0,0.0,0.01,0.3,'robkong')

  #pinch!
  rospy.sleep(1)
  arduino_pub.publish(203)
  rospy.sleep(2)
  #rot2: make pinch tip vertical

  fold(crease_axis,rot2_angle,'robkong')

  listener.waitForTransform("world", "pinch_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_pinch,rot_) = listener.lookupTransform("world", "pinch_tip_kong", rospy.Time(0))
  delta_z=-trans_pinch[2]+0.708+0.04
  move_waypoints(0,0,delta_z,0.03,'robkong')
  #rot3:rot pinch tip for crease 
  fold(crease_axis,rot3_angle,'robkong')
  move_along_axis(perp_axis,-crease_perp_l,'robkong')

  listener.waitForTransform("world", "pinch_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_pinch,rot_) = listener.lookupTransform("world", "pinch_tip_kong", rospy.Time(0))
  delta_z=-trans_pinch[2]+0.708
  move_waypoints(0,0,delta_z,0.03,'robkong')

  ####let arm for pressing the paper go home
  robhong_go_to_home(1)
  #rot4: rot more to leave space for other robot arm
  fold(crease_axis,rot4_angle,'robkong')


#_____INITIALIZATION______#
# We can get the name of the reference frame for this robot:
def init():
  planning_frame = group1.get_planning_frame()
  print "============ Reference frame1: %s" % planning_frame
  planning_frame = group2.get_planning_frame()
  print "============ Reference frame2: %s" % planning_frame
  print "============ Robot Groups:", robot.get_group_names()

#   addCollisionObjects()
#   scene.remove_world_object(wall_name1)
#   scene.remove_world_object(wall_name2)
  robkong_go_to_home(1)
  robhong_go_to_home(1)

  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)

  ### liwei: add wall after go to home
#   scene.add_box(wall_name1,wall_pose1,(2,0.04,2))
#   scene.add_box(wall_name2,wall_pose2,(2,0.04,2)) 




def start_robot():
   init()
   flexflip_2()

   exit()


if __name__=='__main__':
  start_robot()
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
moveit_commander.os._exit(0)
