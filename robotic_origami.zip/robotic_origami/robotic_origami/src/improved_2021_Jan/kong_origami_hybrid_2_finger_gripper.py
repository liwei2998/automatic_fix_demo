#!/usr/bin/env python
import tf_conversions
import numpy 
import message_filters
import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import time
import roslib; roslib.load_manifest('ur_driver')
roslib.load_manifest('ur_moveit_myplan')
import rospy
import actionlib
import tf
from std_msgs.msg import Int8
from ur_moveit_myplan.msg import qr_status
from apriltag_ros.msg import AprilTagDetection, AprilTagDetectionArray
from control_msgs.msg import *
from trajectory_msgs.msg import *
from sensor_msgs.msg import JointState
from math import sqrt, pi, acos, sin, cos
from moveit_msgs.msg import RobotTrajectory
from moveit_msgs.msg import *
from trajectory_msgs.msg import JointTrajectoryPoint
from geometry_msgs.msg import PoseStamped, Pose
from math import sqrt, pi, acos, sin, cos , atan2, tan

from std_msgs.msg import String,Empty,UInt16



rospy.init_node('kong_origami', anonymous=True)
listener = tf.TransformListener()

from arc_rotate import *
from transform_helper import *

## First initialize moveit_commander and rospy.
print "============ Starting tutorial setup"
moveit_commander.roscpp_initialize(sys.argv)

## Instantiate a RobotCommander object.  This object is an interface to
## the robot as a whole.
robot = moveit_commander.RobotCommander()

## Instantiate a PlanningSceneInterface object.  This object is an interface
## to the world surrounding the robot.
scene = moveit_commander.PlanningSceneInterface()

## Instantiate a MoveGroupCommander object.  This object is an interface
## to one group of joints. 
group = moveit_commander.MoveGroupCommander("manipulator")
  
display_trajectory_publisher = rospy.Publisher(
                                    '/move_group/display_planned_path',
                                    moveit_msgs.msg.DisplayTrajectory,
                                    queue_size=20)


print "============ Waiting for RVIZ..."
rospy.sleep(1)

global odom_c_pub
# diaplay center point
odom_c_pub = rospy.Publisher("/odom_c", Odometry, queue_size=50)

#global motion group
global display_trajectory_trigger_pub
display_trajectory_trigger_pub = rospy.Publisher(
                                      '/display_trigger',
                                      String,
                                      queue_size=20)
##def status_callback(qr_status):
##  is_qr = qr_status.status.data
print "============  Start now"


###################################################################################  
def scale_trajectory_speed(traj, scale):
       # Create a new trajectory object
       
       new_traj = RobotTrajectory()
      
       # Initialize the new trajectory to be the same as the planned trajectory
       new_traj.joint_trajectory = traj.joint_trajectory
      
       # Get the number of joints involved
       n_joints = len(traj.joint_trajectory.joint_names)
      
       # Get the number of points on the trajectory
       n_points = len(traj.joint_trajectory.points)
       
       # Store the trajectory points
       points = list(traj.joint_trajectory.points)
      
       # Cycle through all points and scale the time from start, speed and acceleration
       for i in range(n_points):
           point = JointTrajectoryPoint()
           point.time_from_start = traj.joint_trajectory.points[i].time_from_start / scale
           point.velocities = list(traj.joint_trajectory.points[i].velocities)
           point.accelerations = list(traj.joint_trajectory.points[i].accelerations)
           point.positions = traj.joint_trajectory.points[i].positions
                        
           for j in range(n_joints):
               point.velocities[j] = point.velocities[j] * scale
               point.accelerations[j] = point.accelerations[j] * scale * scale
           points[i] = point

       # Assign the modified points to the new trajectory
       new_traj.joint_trajectory.points = points

       # Return the new trajecotry
       return new_traj


#####################################################################################
def add_collision_object1(x_length, y_length, z_length):
  ## Add collision object
  obj_pose = geometry_msgs.msg.PoseStamped()
  obj_pose.header.frame_id = robot.get_planning_frame()
  obj_pose.pose.position.x = 0.
  obj_pose.pose.position.y = 0.
  obj_pose.pose.position.z = -0.15
  scene.add_box("table1", obj_pose, (x_length, y_length, z_length)) # x_axis, y_axis, z_axis

def add_collision_object2(x_length, y_length, z_length):
  ## Add collision object
  obj_pose = geometry_msgs.msg.PoseStamped()
  obj_pose.header.frame_id = robot.get_planning_frame()
  obj_pose.pose.position.x = -0.4
  obj_pose.pose.position.y = 0.
  obj_pose.pose.position.z = 0.5
  scene.add_box("table2", obj_pose, (x_length, y_length, z_length)) 

def add_collision_object3(x_length, y_length, z_length):
  ## Add collision object
  obj_pose = geometry_msgs.msg.PoseStamped()
  obj_pose.header.frame_id = robot.get_planning_frame()
  obj_pose.pose.position.x = 1.2
  obj_pose.pose.position.y = 0.
  obj_pose.pose.position.z = 0.5
  scene.add_box("table3", obj_pose, (x_length, y_length, z_length)) # x_axis, y_axis,



####################################################################################
def go_home():


  ## define home position
  group.clear_pose_targets()

  ## Then, we will get the current set of joint values for the group
  group_variable_values = group.get_current_joint_values()
  print "============ Joint values: ", group_variable_values
  
  ## Now, let's modify joints goal position
  ## To make the end effector vertical to the plane,theta1+theta2+theta3 = -pi/2
  ## Following two sets of values are for left and right arm respectively
  group_variable_values[0] = -pi*50.00/180
  group_variable_values[1] = -pi*74.44/180
  group_variable_values[2] = pi*88.09/180
  group_variable_values[3] = pi*256.4/180
  group_variable_values[4] = -pi*90.37/180
  group_variable_values[5] = pi*40.63/180
  group.set_joint_value_target(group_variable_values)
  plan = group.plan()
  print "============ Waiting while RVIZ displays plan2..."
  rospy.sleep(2)
  scaled_traj2 = scale_trajectory_speed(plan, 0.2)
  group.execute(scaled_traj2)

  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)
#####################################################################

def move_waypoints(px, py, pz, vel):
  waypoints = []
  waypoints.append(group.get_current_pose().pose)
  wpose = copy.deepcopy(group.get_current_pose().pose)
  wpose.position.x += px
  wpose.position.y += py
  wpose.position.z += pz
  waypoints.append(copy.deepcopy(wpose))
  (plan, fraction) = group.compute_cartesian_path(
                               waypoints,   # waypoints to follow
                               0.01,        # eef_step
                               0.0)         # jump_threshold
  print "============ Waiting while RVIZ displays plan3..."
  scaled_traj = scale_trajectory_speed(plan, vel)
  group.execute(scaled_traj)       

#####################################################################
def move_joint(theta0, theta1, theta2, theta3, theta4, theta5, vel):
  group.clear_pose_targets()
  group_variable_values = group.get_current_joint_values()
  group_variable_values[0] += theta0
  group_variable_values[1] += theta1
  group_variable_values[2] += theta2
  group_variable_values[3] += theta3
  group_variable_values[4] += theta4
  group_variable_values[5] += theta5
  group.set_joint_value_target(group_variable_values)
  plan = group.plan()
  print "============ Waiting while RVIZ displays plan2..."
  scaled_traj2 = scale_trajectory_speed(plan, vel)
  group.execute(scaled_traj2)


#######################################################################
def clean_scene():
  # Use the planning scene object to add or remove objects //Interface
  REFERENCE_FRAME = '/world'
  p = PlanningScene()
  p.is_diff = True

  # Create a scene publisher to push changes to the scene //PlanningScene


  # Give each of the scene objects a unique name
  Ground_id = 'ground'
  Card_id = 'card'

  # Remove leftover objects from a previous run
  scene.remove_world_object(Ground_id)
  scene.remove_world_object(Card_id)
  scene_pub.publish(p)
  rospy.sleep(1)
  table_pub.publish('off')
  rospy.sleep(2)

##################################################################
def quat2eular(qx, qy, qz, qw):
  quaternion = (
      qx,
      qy,
      qz,
      qw)
  euler = tf.transformations.euler_from_quaternion(quaternion)
  return euler

#quaternion_from_euler(1, 2, 3, 'ryxz')
###################################################################
def get_tool_position():
  pose_target = group.get_current_pose().pose
  return arc_get_tool_position(pose_target)

################################################################
def group_rotate_by_external_axis(center_point, axis, total_angle):
  global odom_c_pub
  pose_target = group.get_current_pose().pose
  waypoints_new = calc_waypoints_ARC(pose_target, center_point, axis, total_angle, odom_c_pub)
  # Before the execution of the real robot, turn on the display of the end effector's position and orientation
  # display end effector's trajectory
  # subcriber of display_trajectory_trigger and corresponding function is implemented in 'display_markers.py'
  display_trajectory_trigger_pub.publish('on')
  rospy.sleep(1)

  # Utilize 'compute_cartesian_path' to get a smooth trajectory
  (plan3, fraction) = group.compute_cartesian_path(
                               waypoints_new,   # waypoints to follow
                               0.01,        # eef_step
                               0.0)         # jump_threshold

  # Move the robot with the ARC trajectory
  caled_plan = scale_trajectory_speed(plan3, 0.2)
  group.execute(caled_plan)
  rospy.sleep(1)

  # Stop displaying end effector's posision and orientation
  display_trajectory_trigger_pub.publish('close')


def flexflip_1(z_margin):
  #z_margin is a small number for fine tuning of flexflip z-axis
  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)
  rospy.sleep(3)

  listener.waitForTransform("base", "soft_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_soft) = listener.lookupTransform("base", "soft_tip_link", rospy.Time(0))

  listener.waitForTransform("soft_tip_link", "tag_15", rospy.Time(), rospy.Duration(4.0))
  (trans_soft2tag,rot_soft2tag) = listener.lookupTransform("soft_tip_link", "tag_15", rospy.Time(0))

  listener.waitForTransform("rigid_tip_link", "tag_15", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid2tag,rot_rigid2tag) = listener.lookupTransform("rigid_tip_link", "tag_15", rospy.Time(0))
  (trans_tag19,rot_soft) = listener.lookupTransform("world", "tag_19", rospy.Time(0))
  #note that base need to transfer to real world by x=-x and y=-y and numpy array starts at indice 0
  phi =45
  external_axis_center=[-trans_soft[0],-trans_soft[1],trans_soft[2]]
  
  print "======trans_tag"
  print trans_soft2tag
  
  ##################### go to the target initial pose for flex-flip
  group_rotate_by_external_axis(external_axis_center, [0, 0, 1], phi)
  rospy.sleep(1)
  move_waypoints(trans_soft2tag[0]+0.03,-trans_soft2tag[1]+0.01,-trans_rigid2tag[2]-z_margin,0.2)
  rospy.sleep(2)
  ####################################### flex-flip and grasp
  arduino_pub.publish(2)
  rospy.sleep(4)

  move_waypoints(0,0,0.005,0.05)

  listener.waitForTransform("world", "soft_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_soft) = listener.lookupTransform("world", "soft_tip_link", rospy.Time(0))
  #note that base need to transfer to real world by x=-x and y=-y and numpy array starts at indice 0
  phi =15
  external_axis_center=trans_soft
  group_rotate_by_external_axis(external_axis_center, [-0.7071, 0.7071, 0], phi)
  
  rospy.sleep(1)
  arduino_pub.publish(3)
  rospy.sleep(2)


  global_axis=[-0.7071, 0.7071, 0]
  degree=-50
  move_waypoints(0,0,0.01,0.1)
  fold(trans_tag19,global_axis,degree)
  
  # post fold actions
  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_pinch,rot_pinch) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))
  (trans_soft,rot_soft) = listener.lookupTransform("world", "soft_tip_link", rospy.Time(0))
  print "pinch height"
  print trans_pinch
  print "soft height"
  print trans_soft
  tag_dist=0.0282
  move_waypoints(-tag_dist,-tag_dist,-trans_pinch[2]-0.01,0.1)

  rospy.sleep(3)
  arduino_pub.publish(11)
  rospy.sleep(1)

def flexflip_2(z_margin):
  #z_margin is a small number for fine tuning of flexflip z-axis
  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)
  rospy.sleep(3)

  listener.waitForTransform("base", "soft_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_soft) = listener.lookupTransform("base", "soft_tip_link", rospy.Time(0))

  listener.waitForTransform("soft_tip_link", "tag_27", rospy.Time(), rospy.Duration(4.0))
  (trans_soft2tag,rot_soft2tag) = listener.lookupTransform("soft_tip_link", "tag_27", rospy.Time(0))

  listener.waitForTransform("rigid_tip_link", "tag_27", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid2tag,rot_rigid2tag) = listener.lookupTransform("rigid_tip_link", "tag_27", rospy.Time(0))
  (trans_tag20,rot_soft) = listener.lookupTransform("world", "tag_20", rospy.Time(0))
  #note that base need to transfer to real world by x=-x and y=-y and numpy array starts at indice 0
  phi =135
  external_axis_center=[-trans_soft[0],-trans_soft[1],trans_soft[2]]
  
  print "======trans_tag"
  print trans_soft2tag
  
  ##################### go to the target initial pose for flex-flip
  group_rotate_by_external_axis(external_axis_center, [0, 0, 1], phi)
  rospy.sleep(1)
  move_waypoints(trans_soft2tag[0]-0.02,-trans_soft2tag[1]+0.02,-trans_rigid2tag[2]-z_margin,0.2)
  rospy.sleep(2)
  # ####################################### flex-flip and grasp
  arduino_pub.publish(2)
  rospy.sleep(4)

  move_waypoints(0,0,0.005,0.05)

  listener.waitForTransform("world", "soft_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_soft) = listener.lookupTransform("world", "soft_tip_link", rospy.Time(0))
  # #note that base need to transfer to real world by x=-x and y=-y and numpy array starts at indice 0
  phi =15
  external_axis_center=trans_soft
  group_rotate_by_external_axis(external_axis_center, [-0.7071, -0.7071, 0], phi)
  
  rospy.sleep(1)
  arduino_pub.publish(3)
  rospy.sleep(2)


  global_axis=[-0.7071, -0.7071, 0]
  degree=-20
  move_waypoints(0,0,0.01,0.1)
  fold(trans_tag20,global_axis,degree)
  
  # # post fold actions
  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_pinch,rot_pinch) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))
  (trans_soft,rot_soft) = listener.lookupTransform("world", "soft_tip_link", rospy.Time(0))
  print "pinch height"
  print trans_pinch
  print "soft height"
  print trans_soft
  tag_dist=0.0282
  move_waypoints(tag_dist,-tag_dist,-trans_pinch[2]-0.01,0.1)

  rospy.sleep(3)
  arduino_pub.publish(11)
  rospy.sleep(1)


def fold(center_point,global_axis,degree):
  group_rotate_by_external_axis(center_point,global_axis,degree)

def make_a_crease():
  #z_margin is a small number for fine tuning of flexflip z-axis
  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)
  rospy.sleep(3)
  arduino_pub.publish(21)
  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid,rot_rigid) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))

  listener.waitForTransform("pinch_tip_link", "tag_29", rospy.Time(), rospy.Duration(4.0))
  (trans_pinch2tag,rot_pinch2tag) = listener.lookupTransform("pinch_tip_link", "tag_29", rospy.Time(0))
  #(trans_tag20,rot_soft) = listener.lookupTransform("world", "tag_17", rospy.Time(0))
  #note that base need to transfer to real world by x=-x and y=-y and numpy array starts at indice 0

  
  print "======trans_rigid2tag"
  print trans_pinch2tag
  
  ##################### go to the target initial pose for scooping
  phi =-30
  external_axis_center=trans_rigid
  group_rotate_by_external_axis(external_axis_center, [0, 0, 1], phi)
  rospy.sleep(1)

  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid,rot_rigid) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))
  theta=45
  group_rotate_by_external_axis(external_axis_center, [-0.7071, -0.7071, 0], theta)
  rospy.sleep(1)

  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid,rot_rigid) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))
  tag_dist=0.0282
  move_waypoints(trans_pinch2tag[0]-tag_dist,-trans_pinch2tag[1]+2*tag_dist,-trans_rigid[2]-0.027,0.2)
  # rospy.sleep(2)

  ##################  start to make a crease along defined axis
  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid,rot_rigid) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))

  #crease_start_point=trans_rigid
  crease_axis=[0.7071,0.7071,0]
  normal_axis=[0.7071,-0.7071,0]
  crease_length=0.20
  offset_unit=0.03
  shift_unit=0.04
  pinch_dist=[normal_axis[0]*offset_unit,normal_axis[1]*offset_unit,normal_axis[2]*offset_unit]
  shift_dist=[crease_axis[0]*shift_unit,crease_axis[1]*shift_unit,crease_axis[2]*shift_unit]
  num_attempts=int(crease_length//shift_unit)
  print "====pinch attempts"
  print num_attempts
  for i in range(0,num_attempts):
    move_waypoints(pinch_dist[0],pinch_dist[1],pinch_dist[2],0.2)
    arduino_pub.publish(12)
    rospy.sleep(3)
    arduino_pub.publish(11)
    rospy.sleep(3)
    move_waypoints(-pinch_dist[0],-pinch_dist[1],-pinch_dist[2],0.2)
    move_waypoints(shift_dist[0],shift_dist[1],shift_dist[2],0.2)

  move_waypoints(0,0,0.1,0.2)


def scoop_folding():

  # set gripper to pinch state
  arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
  rospy.sleep(1)
  arduino_pub.publish(1)
  rospy.sleep(3)
  arduino_pub.publish(21)

  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid,rot_rigid) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))
  (trans_pinch2tag,rot_pinch2tag) = listener.lookupTransform("pinch_tip_link", "tag_29", rospy.Time(0))
  (trans_fold2tag23,rot_fold2tag23) = listener.lookupTransform("world", "tag_23", rospy.Time(0))
  theta=-30
  external_axis_center=trans_rigid
  group_rotate_by_external_axis(external_axis_center, [0, 1, 0], theta)
  rospy.sleep(1)

  # descend to start pose
  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid,rot_rigid) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))
  tag_dist=0.0282
  move_waypoints(trans_pinch2tag[0]-tag_dist,-trans_pinch2tag[1]+tag_dist,-trans_rigid[2]-0.027,0.2)

  # start scooping pinch
  normal_axis=[1,0,0]
  offset_unit=0.03
  pinch_dist=[normal_axis[0]*offset_unit,normal_axis[1]*offset_unit,normal_axis[2]*offset_unit]
  move_waypoints(pinch_dist[0],pinch_dist[1],pinch_dist[2],0.2)
  arduino_pub.publish(12)
  rospy.sleep(3)
  
  # start folding
  listener.waitForTransform("world", "pinch_tip_link", rospy.Time(), rospy.Duration(4.0))
  (trans_rigid,rot_rigid) = listener.lookupTransform("world", "pinch_tip_link", rospy.Time(0))
  degree=135
  global_axis=[0,1,0]
  center_point=trans_fold2tag23
  group_rotate_by_external_axis(center_point,global_axis,degree)
  arduino_pub.publish(11)
  rospy.sleep(3)
  move_waypoints(0,0,0.1,0.2)
  




########### flex-flip from home_pose
#^^^^^^^^^^^^^start the control logic here ^^^^^^^^^^^^^^^^^^^^^^^^^
####################################################
def main_logic(x_value,z_value,theta_value,i_test):
  #flexflip_1(z_margin=0.004)
  #go_home()
  #flexflip_2(z_margin=0.005)
  #go_home()
  make_a_crease()
  #go_home()
  #scoop_folding()


  

  
  #cam_pose=rospy.wait_for_message('/tag_detections', AprilTagDetectionArray, timeout = 2.0)
  #print cam_pose


    

#####################################################################



            

#######################################################################
def start_robot():

  add_collision_object1(3.0, 3.0, 0.25)
  add_collision_object2(0.1, 2.0, 1)
  add_collision_object3(0.1, 2.0, 1)
  ## Getting Basic Information
  ## We can get the name of the reference frame for this robot
  print "============ Reference frame: %s" % group.get_planning_frame()

  ## We can also print the name of the end-effector link for this group
  print "============ End effector: %s" % group.get_end_effector_link()

  ## We can get a list of all the groups in the robot
  print "============ Robot Groups:"
  print robot.get_group_names()

  ## Sometimes for debugging it is useful to print the entire state of the
  ## robot.
  print "============ Printing robot state"
  print robot.get_current_state()
  ##effector_roll()
  go_home()
  for k in range(0,1):  # theta value
    for m in range(3,4): # x value
      for n in range(2,3): # z value
        main_logic(0.0+m*0.01,0.150+n*0.001,k+0.001,10)

  print "============ STOPPING"
  exit()
##########################################################################

if __name__=='__main__':
  start_robot()
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
moveit_commander.os._exit(0)
