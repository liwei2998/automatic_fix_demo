#!/usr/bin/env python
import tf_conversions
import numpy 
import message_filters
import sys
import copy
import rospy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import time
import roslib; roslib.load_manifest('ur_driver')
roslib.load_manifest('ur_moveit_myplan')
import rospy
import actionlib
import tf
from std_msgs.msg import Int8
from ur_moveit_myplan.msg import qr_status
from apriltag_ros.msg import AprilTagDetection, AprilTagDetectionArray
from control_msgs.msg import *
from trajectory_msgs.msg import *
from sensor_msgs.msg import JointState
from math import sqrt, pi, acos, sin, cos
from moveit_msgs.msg import RobotTrajectory
from moveit_msgs.msg import *
from trajectory_msgs.msg import JointTrajectoryPoint
from geometry_msgs.msg import PoseStamped, Pose
from math import sqrt, pi, acos, sin, cos , atan2, tan

from std_msgs.msg import String,Empty,UInt16



moveit_commander.roscpp_initialize(sys.argv)
rospy.init_node('dual_arm_origami', anonymous=True)
listener = tf.TransformListener()
robot = moveit_commander.RobotCommander()
scene = moveit_commander.PlanningSceneInterface()
rospy.sleep(2)
group_name1 = "hong_arm"
group1 = moveit_commander.MoveGroupCommander(group_name1)
group_name2 = "kong_arm"
group2 = moveit_commander.MoveGroupCommander(group_name2)
display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path',
                                               moveit_msgs.msg.DisplayTrajectory,
                                               queue_size=20)

from arc_rotate import *
global odom_c_pub
# diaplay center point
odom_c_pub = rospy.Publisher("/odom_c", Odometry, queue_size=50)

#global motion group
global display_trajectory_trigger_pub
display_trajectory_trigger_pub = rospy.Publisher(
                                      '/display_trigger',
                                      String,
                                      queue_size=20)

print "============  Start now"


def addCollisionObjects():
    global wall_pose1
    global wall_name1
    wall_pose1 = geometry_msgs.msg.PoseStamped()
    wall_pose1.header.frame_id = "world"
    wall_pose1.pose.orientation.w = 1.0
    wall_pose1.pose.orientation.x = 0
    wall_pose1.pose.orientation.y = 0
    wall_pose1.pose.orientation.z = 1
    wall_pose1.pose.position.x = -2.1
    wall_pose1.pose.position.y = 0.0
    wall_pose1.pose.position.z = 1.0
    wall_name1 = "wall1"
    global wall_pose2
    global wall_name2
    wall_pose2 = geometry_msgs.msg.PoseStamped()
    wall_pose2.header.frame_id = "world"
    wall_pose2.pose.orientation.w = 1.0
    wall_pose2.pose.orientation.x = 0
    wall_pose2.pose.orientation.y = 0
    wall_pose2.pose.orientation.z = 1
    wall_pose2.pose.position.x = 2.1
    wall_pose2.pose.position.y = 0.0
    wall_pose2.pose.position.z = 1.0
    wall_name2 = "wall2"  

    
#    hongjoint_values = [-51.56/180*pi, -80.46/180*pi, -114.9/180*pi, -50.93/180*pi, 70.64/180*pi, -54.45/180*pi]
def robhong_go_to_home(state):
    if state == 1:        
        joint_values = [-66.86/180*pi, -69.6/180*pi, -120.2/180*pi, -51.78/180*pi, 77.87/180*pi, 111.00/180*pi]
    elif state == 2:
        joint_values = []
    group1.set_joint_value_target(joint_values)
    plan = group1.plan()
    print "============ hong_home"
    rospy.sleep(2)
    scaled_traj2 = scale_trajectory_speed(plan, 0.3)
    group1.execute(scaled_traj2)

def robkong_go_to_home(state):
    if state == 1:
        joint_values = [45.80/180*pi, -108.10/180*pi, 111.35/180*pi, -113.3/180*pi, -72.05/180*pi, 47.2/180*pi]
    elif state == 2:
        joint_values = []
    group2.set_joint_value_target(joint_values)
    plan = group2.plan()
    print "============ kong_home."
    rospy.sleep(2)
    scaled_traj2 = scale_trajectory_speed(plan, 0.3)
    group2.execute(scaled_traj2)

def move_target(x, y, z, ox, oy, oz, ow, vel,robot_arm):

  if robot_arm == "robhong":
      group = group1
  elif robot_arm == "robkong":
      group = group2
  else:
      print "robot_arm input error, please input valid robot_arm name"
  return 0      
  pose_target = geometry_msgs.msg.Pose()
  pose_target.orientation.x = ox
  pose_target.orientation.y = oy
  pose_target.orientation.z = oz
  pose_target.orientation.w = ow
  pose_target.position.x = x
  pose_target.position.y = y
  pose_target.position.z = z
  group.set_pose_target(pose_target)
  plan = group.plan()
  scaled_traj = scale_trajectory_speed(plan, vel)
  print "move_target"
  group.execute(scaled_traj)

def move_waypoints(dx,dy,dz,vel,robot_arm):
    '''
    This function is used for moving position of tool0 link of robot_arm.
    Input: difference between target position and initial position
    Output: execute a straight line trajectory between target and initial position
    '''
    if robot_arm == "robhong":
        group = group1
    elif robot_arm == "robkong":
        group = group2
    else:
        print "robot_arm input error, please input valid robot_arm name"
        return 0        
    waypoints = []
    waypoints.append(group.get_current_pose().pose)
    wpose = copy.deepcopy(group.get_current_pose().pose)
    wpose.position.x += dx
    wpose.position.y += dy
    wpose.position.z += dz
    waypoints.append(copy.deepcopy(wpose))
    (plan, fraction) = group.compute_cartesian_path(waypoints, 0.01, 0.0)
    new_traj = scale_trajectory_speed(plan,vel)
    result=group.execute(new_traj)
    if result==1:  
        return 1
        print "move waypoint success"
    else:
        # else return 0
        return 0
        print "move waypoint failure"
    


def scale_trajectory_speed(traj, scale):
    new_traj = moveit_msgs.msg.RobotTrajectory()
    new_traj.joint_trajectory = traj.joint_trajectory
    n_joints = len(traj.joint_trajectory.joint_names)
    n_points = len(traj.joint_trajectory.points)
    points = list(traj.joint_trajectory.points)

    for i in range(n_points):
        point = trajectory_msgs.msg.JointTrajectoryPoint()
        point.time_from_start = traj.joint_trajectory.points[i].time_from_start / scale
        point.velocities = list(traj.joint_trajectory.points[i].velocities)
        point.accelerations = list(traj.joint_trajectory.points[i].accelerations)
        point.positions = traj.joint_trajectory.points[i].positions

        for j in range(n_joints):
            point.velocities[j] = point.velocities[j] * scale
            point.accelerations[j] = point.accelerations[j] * scale * scale
        points[i] = point

    new_traj.joint_trajectory.points = points
    return new_traj
  


def fold(center_point,global_axis,degree,robot_arm):
  if robot_arm == "robhong":
      group = group1
  elif robot_arm == "robkong":
      group = group2
  else:
      print "robot_arm input error, please input valid robot_arm name"
      return 0       
  group_rotate_by_external_axis(center_point,global_axis,degree,group)

def group_rotate_by_external_axis(center_point, axis, total_angle,robot_arm):
  global odom_c_pub
  if robot_arm == "robhong":
      group = group1
  elif robot_arm == "robkong":
      group = group2
  else:
      print "robot_arm input error, please input valid robot_arm name"
      return 0   
  pose_target = group.get_current_pose().pose
  
  waypoints_new = calc_waypoints_ARC(pose_target, center_point, axis, total_angle, odom_c_pub)
  # Before the execution of the real robot, turn on the display of the end effector's position and orientation
  # display end effector's trajectory
  # subcriber of display_trajectory_trigger and corresponding function is implemented in 'display_markers.py'
  display_trajectory_trigger_pub.publish('on')
  rospy.sleep(1)

  # Utilize 'compute_cartesian_path' to get a smooth trajectory
  (plan3, fraction) = group.compute_cartesian_path(
                               waypoints_new,   # waypoints to follow
                               0.01,        # eef_step
                               0.0)         # jump_threshold

  # Move the robot with the ARC trajectory
  caled_plan = scale_trajectory_speed(plan3, 0.3)
  group.execute(caled_plan)
  rospy.sleep(1)

  # Stop displaying end effector's posision and orientation
  display_trajectory_trigger_pub.publish('close')

def flexflip_1(z_margin):
  #z_margin is a small number for fine tuning of flexflip z-axis
#   arduino_pub = rospy.Publisher('/hybrid', UInt16, queue_size=1)
#   rospy.sleep(1)
#   arduino_pub.publish(1)
#   rospy.sleep(3)



#   listener.waitForTransform("soft_tip_kong", "tag_15", rospy.Time(), rospy.Duration(4.0))
#   (trans_soft2tag,rot_soft2tag) = listener.lookupTransform("soft_tip_kong", "tag_15", rospy.Time(0))

#   listener.waitForTransform("rigid_tip_kong", "tag_15", rospy.Time(), rospy.Duration(4.0))
#   (trans_rigid2tag,rot_rigid2tag) = listener.lookupTransform("rigid_tip_kong", "tag_15", rospy.Time(0))
#   (trans_tag19,rot_soft) = listener.lookupTransform("world", "tag_19", rospy.Time(0))
  #note that base need to transfer to real world by x=-x and y=-y and numpy array starts at indice 0


  ##############kong_arm to initial pose
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  (trans_tag15,rot_) = listener.lookupTransform("world", "tag_15", rospy.Time(0))
  (trans_tag29,rot_) = listener.lookupTransform("world", "tag_29", rospy.Time(0))
  trans_soft2tag = np.subtract(trans_tag15,trans_soft,).tolist()
  move_waypoints(trans_soft2tag[0]+0.03,trans_soft2tag[1]+0.01,0,0.3,'robkong')

  phi=30
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  group_rotate_by_external_axis(trans_soft, [0, 1, 0], phi,"robkong")
  phi=-45
  listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_soft,rot_) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  group_rotate_by_external_axis(trans_soft, [0, 0, 1], phi,"robkong")
  po_cr = group2.get_current_pose().pose

  #kong_arm descend
  listener.waitForTransform("world", "rigid_tip_kong", rospy.Time(), rospy.Duration(4.0))
  (trans_rig,rot_) = listener.lookupTransform("world", "rigid_tip_kong", rospy.Time(0))
  trans_rig2tag= np.subtract(trans_tag15,trans_rig,).tolist()
  move_waypoints(0,0,trans_rig2tag[2]+0.01,0.3,'robkong')
 # move_target(po_cr.position.x, po_cr.position.y, po_cr.position.z, 0, -1, 0, 0,0.2,'robkong')


  ##############hong_arm to fix the object
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  trans_rig2tag = np.subtract(trans_tag29,trans_rigH,).tolist()
  move_waypoints(trans_rig2tag[0]-0.01,trans_rig2tag[1]+0.01,0.15,0.3,'robhong')

  phi=-30
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  group_rotate_by_external_axis(trans_rigH, [0, 1, 0], phi,"robhong")
  phi=-45
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  group_rotate_by_external_axis(trans_rigH, [0, 0, 1], phi,"robhong")

  #hong_arm descend
  listener.waitForTransform("world", "rigid_tip_hong", rospy.Time(), rospy.Duration(4.0))
  (trans_rigH,rot_) = listener.lookupTransform("world", "rigid_tip_hong", rospy.Time(0))
  trans_rig2tag= np.subtract(trans_tag29,trans_rigH,).tolist()
  move_waypoints(0,0,trans_rig2tag[2]+0.01,0.3,'robhong')
 
 
  phi =-45
  external_axis_center=trans_soft

  print "trans_soft"
  print trans_soft
  print "trans_tag15"
  print trans_tag15
  print "trans_tag29"
  print trans_tag29
  print "current_pos"
  print po_cr

#   listener.waitForTransform("rigid_tip_kong", "tag_15", rospy.Time(), rospy.Duration(4.0))
#   (trans_rigid2tag,rot_rigid2tag) = listener.lookupTransform("rigid_tip_kong", "tag_15", rospy.Time(0))

  ##################### go to the target initial pose for flex-flip
  
#  
#  rospy.sleep(1)

#  move_waypoints(trans_soft2tag[0]+0.03,-trans_soft2tag[1]+0.01,-trans_rigid2tag[2]-z_margin,0.2,'robkong')
#   rospy.sleep(2)
  ####################################### flex-flip and grasp
#   arduino_pub.publish(2)
#   rospy.sleep(4)

#   move_waypoints(0,0,0.005,0.05,'robkong')

#   listener.waitForTransform("world", "soft_tip_kong", rospy.Time(), rospy.Duration(4.0))
#   (trans_soft,rot_soft) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
  #note that base need to transfer to real world by x=-x and y=-y and numpy array starts at indice 0
#   phi =15
#   external_axis_center=trans_soft
#   group_rotate_by_external_axis(external_axis_center, [-0.7071, 0.7071, 0], phi,"robkong")
  
#   rospy.sleep(1)
#   arduino_pub.publish(3)
#   rospy.sleep(2)


#   global_axis=[-0.7071, 0.7071, 0]
#   degree=-50
#   move_waypoints(0,0,0.01,0.1,'robkong')
#   fold(trans_tag19,global_axis,degree,'robkong')
  
#   # post fold actions
#   listener.waitForTransform("world", "pinch_tip_kong", rospy.Time(), rospy.Duration(4.0))
#   (trans_pinch,rot_pinch) = listener.lookupTransform("world", "pinch_tip_kong", rospy.Time(0))
#   (trans_soft,rot_soft) = listener.lookupTransform("world", "soft_tip_kong", rospy.Time(0))
#   print "pinch height"
#   print trans_pinch
#   print "soft height"
#   print trans_soft
#   tag_dist=0.0282
#   move_waypoints(-tag_dist,-tag_dist,-trans_pinch[2]-0.01,0.1,'robkong')

#   rospy.sleep(3)
#   arduino_pub.publish(11)
#   rospy.sleep(1)

#_____INITIALIZATION______#
# We can get the name of the reference frame for this robot:
def init():
  planning_frame = group1.get_planning_frame()
  print "============ Reference frame1: %s" % planning_frame
  eef_link = group1.get_end_effector_link()
  print "============ End effector1: %s" % eef_link
  planning_frame = group2.get_planning_frame()
  print "============ Reference frame2: %s" % planning_frame
  eef_link = group2.get_end_effector_link()
  print "============ End effector2: %s" % eef_link
  print "============ Robot Groups:", robot.get_group_names()

#   addCollisionObjects()
#   scene.remove_world_object(wall_name1)
#   scene.remove_world_object(wall_name2)
  robkong_go_to_home(1)
  robhong_go_to_home(1)

  ### liwei: add wall after go to home
#   scene.add_box(wall_name1,wall_pose1,(2,0.04,2))
#   scene.add_box(wall_name2,wall_pose2,(2,0.04,2)) 




def start_robot():
   init()
   flexflip_1(-0.2)

   exit()


if __name__=='__main__':
  start_robot()
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print("Shutting down")
moveit_commander.os._exit(0)
