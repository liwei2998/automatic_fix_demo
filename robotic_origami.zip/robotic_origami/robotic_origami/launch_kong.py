## using roslaunch API to launch multiple launch file
## http://wiki.ros.org/roslaunch/API%20Usage

import roslaunch

