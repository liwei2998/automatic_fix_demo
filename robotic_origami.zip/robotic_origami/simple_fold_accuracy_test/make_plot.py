import matplotlib.pyplot as plt
import sys
import numpy as np

plt.close('all')

def ReadFile():
    array = []
    with open('diag_data2.txt', 'rt') as myFile:
        for line in myFile:
            if not line.startswith("d"):
		array.append(map(int, line.split(',')))
    return array

result = ReadFile()
output=np.array(result)

plt.plot(output[:,0]/15.727,output[:,1]/15.727, 'ro')
plt.plot(output[9,0]/15.727,output[9,1]/15.727, 'bo')
plt.axis([0, 210, 0, 297])
plt.gca().set_aspect('equal', adjustable='box')
plt.ylabel('y axis in mm')
plt.xlabel('x axis in mm')
plt.show()


x_sd=np.std(output[:,0]/15.727)
y_sd=np.std(output[:,1]/15.727)

print "x_sd",x_sd
print "y_sd",y_sd

x_mean=np.mean(output[:,0]/15.727)
y_mean=np.mean(output[:,1]/15.727)

print "x_mean",x_mean
print "y_mean",y_mean

print "x_expect",output[9,0]/15.727
print "y_expect",output[9,1]/15.727

sys.exit()
